from .base import PipelineLDA, main




def main():
    print 'executing...'
    main()

