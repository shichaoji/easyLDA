easily bult LDA Topic Models with just a list of docs (e.g. a list of twitter posts in CSV/TXT
